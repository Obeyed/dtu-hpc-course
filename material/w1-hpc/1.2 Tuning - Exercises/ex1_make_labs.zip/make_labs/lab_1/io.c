#include <stdio.h>
#include "io.h"
void 
io(void) { 
    printf("Doing I/O\n");
};
