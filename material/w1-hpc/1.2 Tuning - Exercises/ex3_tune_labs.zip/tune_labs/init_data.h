#ifndef __INIT_DATA_H
#define __INIT_DATA_H

#include "data.h"

void init_data(particle_t *, int);

#endif
