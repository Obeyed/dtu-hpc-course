#include "distance.h"
#include <unistd.h>

#ifdef ALL_IN_ONE

double 
distance(particle_t *p, int n) {
    // dummy code - please change
    sleep(1);
    return(-1.0);
}

#else

double 
distance(particle_t *p, double *v, int n) {
    // dummy code - please change
    sleep(1);
    return(-1.0);
}

#endif
